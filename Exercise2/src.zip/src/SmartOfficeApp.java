import java.util.Scanner;

public class SmartOfficeApp {
    public static void main(String[] args) {
        OfficeConfig office = OfficeConfig.getInstance();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter command (config/capacity/booking/add/cancel/vacate/exit : "); //
            String command = scanner.next().trim().toLowerCase();

            switch (command) {
                case "config":
                    System.out.print("Config room count: ");
                    int numberOfRooms = scanner.nextInt();
                    office.configureRooms(numberOfRooms);
                    break;

                case "capacity":
                    System.out.print("Enter room number: ");
                    int roomId = scanner.nextInt();
                    System.out.print("config rom capacity: ");
                    int capacity = scanner.nextInt();
                    office.setRoomCapacity(roomId, capacity);
                    break;

                case "add":
                    System.out.print("Enter room number: ");
                    roomId = scanner.nextInt();
                    System.out.print("Add occupant: ");
                    int numberOfPeople = scanner.nextInt();
                    Room room = office.getRoom(roomId);
                    if (room != null) {
                        room.occupy(numberOfPeople);
                    } else {
                        System.out.println("Room " + roomId + " does not exist.");
                    }
                    break;

                case "booking":
                    System.out.print("Enter room number: ");
                    roomId = scanner.nextInt();
                    System.out.print("block room (HH:mm): ");
                    String startTime = scanner.next();
                    System.out.print("Enter duration in minutes: ");
                    int duration = scanner.nextInt();
                    room = office.getRoom(roomId);
                    if (room != null) {
                        room.book(startTime, duration);
                    } else {
                        System.out.println("Invalid room number. Please enter a valid room number.");
                    }
                    break;

                case "cancel":
                    System.out.print("Enter room number: ");
                    roomId = scanner.nextInt();
                    room = office.getRoom(roomId);
                    if (room != null) {
                        room.cancel();
                    } else {
                        System.out.println("Room " + roomId + " is not booked. Cannot cancel booking.");
                    }
                    break;

                /*case "occupy":
                    System.out.print("Enter room number: ");
                    roomId = scanner.nextInt();
                    System.out.print("Enter number of occupants: ");
                    numberOfPeople = scanner.nextInt();
                    room = office.getRoom(roomId);
                    if (room != null) {
                        room.occupy(numberOfPeople);
                    } else {
                        System.out.println("Room " + roomId + " does not exist.");
                    }
                    break;*/

                case "vacate":
                    System.out.print("Enter room number: ");
                    roomId = scanner.nextInt();
                    room = office.getRoom(roomId);
                    if (room != null) {
                        room.vacate();
                    } else {
                        System.out.println("Room " + roomId + " does not exist.");
                    }
                    break;

                case "exit":
                    scanner.close();
                    System.exit(0);


                default:
                    System.out.println("Invalid command. Please enter a valid command.");
            }
        }
    }
}
